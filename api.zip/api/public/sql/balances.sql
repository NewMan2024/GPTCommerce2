INSERT INTO `balances` (`id`, `shop_id`, `admin_commission_rate`, `total_earnings`, `withdrawn_amount`, `current_balance`, `payment_info`, `created_at`, `updated_at`) VALUES
(1, 1, 10, 0, 0, 0, '{\"bank\": \"Bank1\", \"name\": \"furniture shop\", \"email\": \"furniture@demo.com\", \"account\": 1121213131414141}', '2021-06-27 08:54:32', '2021-06-30 14:14:40'),
(4, 6, 10, 0, 0, 0, '{\"bank\": \"Bank6\", \"name\": \"Grocery Shop\", \"email\": \"grocery@demo.com\", \"account\": 231321635465465}', '2021-06-28 03:48:49', '2021-12-07 11:53:18'),
(5, 5, 10, 0, 0, 0, '{\"bank\": \"Bank5\", \"name\": \"Bakery Shop\", \"email\": \"bakery@demo.com\", \"account\": 86453213548641330}', '2021-06-28 03:49:25', '2021-06-30 14:23:05'),
(6, 4, 10, 0, 0, 0, '{\"bank\": \"Bank4\", \"name\": \"Makeup Shop\", \"email\": \"makeup@demo.com\", \"account\": 5.6210303648761e18}', '2021-06-28 03:49:56', '2021-06-30 14:17:44'),
(7, 3, 10, 0, 0, 0, '{\"bank\": \"Bank3\", \"name\": \"Bag Shop\", \"email\": \"bag@demo.com\", \"account\": 632145987000364}', '2021-06-28 03:50:00', '2021-06-30 14:23:46'),
(8, 2, 10, 0, 0, 0, '{\"bank\": \"Bank2\", \"name\": \"Clothing Shop\", \"email\": \"clothing@demo.com\", \"account\": 1236521002454}', '2021-06-28 03:50:04', '2021-06-30 14:19:31'),
(9, 7, 10, 0, 0, 0, '{\"bank\": \"book bank\", \"name\": \"book shop\", \"email\": \"admin@example.com\", \"account\": 123456789}', '2021-12-07 16:47:07', '2021-12-16 16:42:14');
