<?php
return [
    'view-order'  => 'Bestellung ansehen',
    'thanks'      => 'Vielen Dank',
    'view-refund' => 'Rückerstattung ansehen',
];
