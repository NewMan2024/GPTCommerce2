<?php
return [
    'welcome' => 'Welcome',
];
